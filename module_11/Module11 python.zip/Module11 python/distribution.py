import mysql.connector
from mysql.connector import errorcode

config = {
    "user": "Bacchus_supplies",
    "password": "Password",
    "host": "localhost",
    "port": "3306",
    "database": "bacchus",
    "raise_on_warnings": True
}

try:
    db = mysql.connector.connect(**config)
    print("\n Database user {} connected to MySQL on host {} with database {}".format(config["user"], config["host"],
                                                                              config["port"], config["database"]))
    input("\n\n Press any key to continue...")

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print(" The supplied username or password are invalid")

    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print(" The specified database does not exist")

    else:
        print(err)

finally:

    def show_orders(cursor, title):
        # method to inner join tables customer orders report

        cursor = db.cursor(cursor, title)

        # inner join query on customer orders
        cursor.execute("SELECT distributor.Distributor_Name AS Distributor, wine.Wine_Product_type AS Wine,\
            orders.Order_Quantity AS Quantity, orders.Order_Ship_Date AS 'Ship Date' FROM orders INNER JOIN distributor\
            ON orders.Order_Customer_ID = distributor.Distributor_Customer_ID INNER JOIN wine\
            ON orders.Order_Product_ID = wine.Wine_Product_ID ORDER BY distributor.Distributor_Name")

        # get the results from the customer orders query
        orders = cursor.fetchall()

        print("\n -- {} --".format(title))

        # iterate over the order data set and display the results
        for order in orders:
            print("Distributor: {}\nWine: {}\nQuantity: {}\nShip Date: {}\n".format(order[0], order[1],\
                order[2], order[3]))
        return;


    def show_chardonnayDistributors(cursor, title):
        # method to inner join tables customer orders report

        cursor = db.cursor(cursor, title)

        # inner join query on customer orders
        cursor.execute("SELECT DISTINCT distributor.Distributor_Name AS Distributor FROM orders INNER JOIN distributor\
            ON orders.Order_Customer_ID = distributor.Distributor_Customer_ID WHERE orders.Order_Product_ID = '4'")

        # get the results from the customer orders query
        distributors = cursor.fetchall()

        print("\n -- {} --".format(title))

        # iterate over the order data set and display the results
        for distributor in distributors:
            print("       {}".format(distributor[0]))
        return;

    def show_merlotDistributors(cursor, title):
        # method to inner join tables customer orders report

        cursor = db.cursor(cursor, title)

        # inner join query on customer orders
        cursor.execute("SELECT DISTINCT distributor.Distributor_Name AS Distributor FROM orders INNER JOIN distributor\
            ON orders.Order_Customer_ID = distributor.Distributor_Customer_ID WHERE orders.Order_Product_ID = '1'")

        # get the results from the customer orders query
        distributors = cursor.fetchall()

        print("\n -- {} --".format(title))

        # iterate over the order data set and display the results
        for distributor in distributors:
            print("       {}".format(distributor[0]))
        return;

    def show_cabernetDistributors(cursor, title):
        # method to inner join tables customer orders report

        cursor = db.cursor(cursor, title)

        # inner join query on customer orders
        cursor.execute("SELECT DISTINCT distributor.Distributor_Name AS Distributor FROM orders INNER JOIN distributor\
            ON orders.Order_Customer_ID = distributor.Distributor_Customer_ID WHERE orders.Order_Product_ID = '2'")

        # get the results from the customer orders query
        distributors = cursor.fetchall()

        print("\n -- {} --".format(title))

        # iterate over the order data set and display the results
        for distributor in distributors:
            print("       {}".format(distributor[0]))
        return;

    def show_chablisDistributors(cursor, title):
        # method to inner join tables customer orders report

        cursor = db.cursor(cursor, title)

        # inner join query on customer orders
        cursor.execute("SELECT DISTINCT distributor.Distributor_Name AS Distributor,\
            SUM(orders.Order_Quantity) AS 'Total Qty Sold' FROM orders INNER JOIN distributor\
            ON orders.Order_Customer_ID = distributor.Distributor_Customer_ID WHERE orders.Order_Product_ID = '3'")

        # get the results from the customer orders query
        distributors = cursor.fetchall()

        print("\n -- {} --".format(title))

        # iterate over the order data set and display the results
        for distributor in distributors:
            print("       {}".format(distributor[0]))

        return;

    def show_quantitiesSold(cursor, title):
        # method to inner join tables customer orders report

        cursor = db.cursor(cursor, title)


        # inner join query on customer orders
        cursor.execute("SELECT wine.Wine_Product_type AS Wine, orders.Order_Product_ID AS Product,\
            SUM(orders.Order_Quantity) AS 'Total Qty Sold', projections.Projections_Sales_Projections AS 'Sales Projections'\
            FROM orders INNER JOIN wine ON orders.Order_Product_ID = wine.Wine_Product_ID INNER JOIN projections\
            ON orders.Order_Product_ID = projections.Projections_Product_ID GROUP BY orders.Order_Product_ID")

        # get the results from the customer orders query
        quantities = cursor.fetchall()

        print("\n -- {} --".format(title))

        # iterate over the order data set and display the results
        for quantity in quantities:
            print("Wine: {}\nTotal Qty Sold: {}\nProjected Qty Sold: {}\nPerformance: {}\n".format(quantity[0], quantity[2],\
                                                                                    quantity[3], quantity[3] - quantity[2]))

        return;

    cursor = db.cursor()

    # Printing the orders
    show_orders(cursor, "Displaying Orders")

    # Printing the Merlot Distributors
    show_merlotDistributors(cursor, "Merlot Distributors")

    # Printing the Cabernet Distributors
    show_cabernetDistributors(cursor, "Cabernet Distributors")

    # Printing the Chablis Distributors
    show_chablisDistributors(cursor, "Chablis Distributors")

    # Printing the Chardonnay Distributors
    show_chardonnayDistributors(cursor, "Chardonnay Distributors")

    # Printing Quantities of Wine Sold - sorted by wine
    show_quantitiesSold(cursor, "Quantities Sold")



db.close()



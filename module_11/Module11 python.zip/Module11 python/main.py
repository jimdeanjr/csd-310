import mysql.connector
from mysql.connector import errorcode

config = {
    "user": "root",
    "password": "T%rterr@425",
    "host": "127.0.0.1",
    "port": "51502",
    "database": "Bacchus",
    "raise_on_warnings": True
}

try:
    db = mysql.connector.connect(**config)
    cursor = db.cursor()

    cursor.execute("SELECT * FROM Personnel")
    employees = cursor.fetchall()

    print("\n -- {} --".format("EMPLOYEES"))
    for employee in employees:
        print("ID: {}\nName: {} {}\nJob Title: {}\nQ1 Hours Worked: {}"
              "\nQ2 Hours Worked: {}\nQ3 Hours Worked: {}\nQ4 Hours Worked: {}\n".format(
               employee[0], employee[1], employee[2], employee[3], employee[4],
               employee[5], employee[6], employee[7]
               ))

    db.close()

    input("Press any key to continue...")
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("  The supplied username or password are invalid.")

    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("  The specified database does not exist.")

    else:
        print(err)
